from flask import Flask, render_template, request
import pg8000

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # Get the level from the form submission
        level = request.form["level"]
        # Redirect to the timetable page with selected level
        return render_template("timetable.html", level=level, data=[], message="Loading timetable...")

    # Render the index.html template
    return render_template("index.html")


@app.route("/timetable", methods=["GET"])
def timetable():
    # Get level from the query parameters
    level = request.args.get('level')
    if not level:
        return "Level not provided", 400

    # Connect to the PostgreSQL database
    try:
        conn = pg8000.connect(
            user="mukhammad",
            password="mukhammad",
            host="localhost",
            port=5433,
            database="mukhammad"
        )

        # Fetch timetable data for the selected level
        cur = conn.cursor()
        query = "SELECT * FROM Timetable WHERE level = %s;"
        cur.execute(query, (level,))
        rows = cur.fetchall()

        cur.close()
        conn.close()

        # Pass data to the timetable.html template
        if rows:
            return render_template("timetable.html", level=level, data=rows, message="")
        else:
            return render_template("timetable.html", level=level, data=[], message="No data found for this level.")
    except Exception as e:
        return f"An error occurred: {e}", 500


if __name__ == "__main__":
    app.run(debug=True)
